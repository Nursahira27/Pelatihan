<?php
$coon = mysqli_connect("localhost","root", "" ,"kampus");
// if ($coon == true) {
//     echo "berhasil terhubung ke database";
// } else {
//     echo "gagal terbuhung ke database";
// }